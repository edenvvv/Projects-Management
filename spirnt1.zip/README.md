# Projects-Management

## <a href="https://projects-management-ade.herokuapp.com/">Live Demo</a>

## Modules requirements:
`npm install express`<br/>
`npm install nodemon`<br/>
`npm install ejs`

## Run:
`npm run dev`
